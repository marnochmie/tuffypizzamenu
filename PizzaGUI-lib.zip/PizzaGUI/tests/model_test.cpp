// Host-side test of the pure C++ menu model:  g++ -std=c++20 -Iinclude tests/model_test.cpp src/Model.cpp -o model_test && ./model_test
#include <cassert>
#include <cstdio>
#include "pizzagui/Model.hpp"
using namespace pizzagui;

static NavInput Press(bool sel, float x = 0, float y = 0, bool mod = true) { NavInput n; n.modifier = mod; n.select = sel; n.stick = {x, y}; return n; }
#define CHECK(c) do { if (!(c)) { std::printf("FAIL line %d: %s\n", __LINE__, #c); return 1; } } while (0)

int main() {
    MenuModel m;
    int ticks = 0, enables = 0, disables = 0, presses = 0, lastSlide = -1;

    Category& move = m.CreateCategory("Movement");
    m.Root().AddSubmenu("Movement", move);
    move.AddToggle("Fly", [&] { ++ticks; }, [&] { ++enables; }, [&] { ++disables; });
    move.AddButton("Reset", [&] { ++presses; });
    move.AddSlider("Speed", 0, 4, [&](int v) { lastSlide = v; }, 1).valueNames = {"slow", "ok", "fast", "faster", "max"};

    // Root: cursor on "Movement" -> select opens submenu (no Back entry at root)
    double t = 0;
    CHECK(m.Current().Name() == "Home");
    auto r = m.Navigate(Press(true), t); CHECK(r.activated);
    CHECK(m.Current().Name() == "Movement");
    CHECK(m.Navigate(Press(false), t += 0.016).activated == false);   // release clears latch

    // Movement: entries = [Back, Fly, Reset, Speed]; cursor 0 = Back
    CHECK(m.CursorIndex() == 0);
    m.Navigate(Press(false, 0, -1), t += 0.5);                         // down -> Fly
    CHECK(m.CursorIndex() == 1);
    m.Navigate(Press(false, 0, -1), t += 0.01);                        // within repeat delay -> ignored
    CHECK(m.CursorIndex() == 1);

    m.Navigate(Press(true), t += 0.5);                                 // toggle Fly on
    CHECK(enables == 1 && m.FindItem("Fly")->enabled);
    m.Navigate(Press(true), t += 0.016);                               // held: latch -> no re-fire
    CHECK(enables == 1);
    m.Navigate(Press(false), t += 0.016);
    m.RunToggles(); m.RunToggles();
    CHECK(ticks == 2);

    // no modifier held -> menu ignores input
    m.Navigate(Press(true, 0, -1, false), t += 0.5);
    CHECK(m.CursorIndex() == 1);
    m.Navigate(Press(false, 0, 0, false), t += 0.016);

    // slider: go to Speed (2 downs), then right x2 (clamped by delay), check value & callback
    m.Navigate(Press(false, 0, -1), t += 0.5);                         // Reset
    m.Navigate(Press(false, 0, -1), t += 0.5);                         // Speed
    m.Navigate(Press(false, 1, 0), t += 0.5);
    CHECK(m.FindItem("Speed")->value == 2 && lastSlide == 2);
    for (int i = 0; i < 6; ++i) m.Navigate(Press(false, 1, 0), t += 0.5);
    CHECK(m.FindItem("Speed")->value == 4);                            // clamped
    CHECK(m.FindItem("Speed")->DisplayName() == "Speed (max) [5/5]");

    // wrap: down from last entry -> first (Back)
    m.Navigate(Press(false, 0, -1), t += 0.5);
    CHECK(m.CursorIndex() == 0);
    m.Navigate(Press(true), t += 0.5);                                 // Back
    CHECK(m.Current().Name() == "Home");
    m.Navigate(Press(false), t += 0.016);

    // paging: 20 buttons with 8 per page -> 3 pages, Prev/Next entries
    Category& big = m.CreateCategory("Big");
    m.Root().AddSubmenu("Big", big);
    for (int i = 0; i < 20; ++i) big.AddButton("B" + std::to_string(i), [] {});
    m.Open(big);
    CHECK(m.PageCount() == 3);
    std::string txt = m.BuildText();
    CHECK(txt.find("[1/3]") != std::string::npos);
    CHECK(txt.find("Next ->") != std::string::npos);
    // entries: Back, B0..B7, Prev, Next -> Next is index 10
    for (int i = 0; i < 10; ++i) m.Navigate(Press(false, 0, -1), t += 0.5);
    CHECK(m.CursorIndex() == 10);
    m.Navigate(Press(true), t += 0.5);
    CHECK(m.PageIndex() == 1);
    m.Navigate(Press(false), t += 0.016);
    CHECK(m.BuildText().find("B8") != std::string::npos);
    m.Navigate(Press(true), t += 0.5); m.Navigate(Press(false), t += 0.016);
    m.Navigate(Press(true), t += 0.5); m.Navigate(Press(false), t += 0.016);
    CHECK(m.PageIndex() == 0);                                         // wrapped 1->2->0

    // rendering
    MenuModel m2;
    m2.Root().AddToggle("Alpha");
    m2.theme = Theme::Ascii(); m2.theme.title = "Hi";
    std::string s = m2.BuildText();
    CHECK(s.find("<color=#FF9000>H</color><color=#FF5500>i</color>") != std::string::npos);
    CHECK(s.find("[1/1]") != std::string::npos);
    CHECK(s.find("<color=#C9A071>></color> <b><color=#FF9000>Alpha</color></b>") != std::string::npos);
    CHECK(s.find("[-]") == std::string::npos);                         // toggleOff uses coloured '-'
    CHECK(s.find("<color=red>-</color>") != std::string::npos);

    // original-look default theme (title "Pizza", UTF-8 arrow intact)
    MenuModel m3; m3.Root().AddButton("x", {});
    std::string d = m3.BuildText();
    CHECK(d.find("\xE2\x96\xB2") != std::string::npos && d.find("\xE2\x86\x92") != std::string::npos);
    CHECK(d.find("<color=#FF9000>P</color><color=#FF5500>i</color><color=#FF9000>z</color><color=#FF5500>z</color><color=#FF9000>a</color>") != std::string::npos);

    // empty menu must not crash
    MenuModel m4; m4.Navigate(Press(true, 0, 1), 1.0); (void)m4.BuildText();

    // throwing callbacks are contained
    MenuModel m5; m5.Root().AddToggle("Boom", [] { throw 1; }).enabled = true; m5.RunToggles();

    std::printf("ALL OK\n");
    return 0;
}
