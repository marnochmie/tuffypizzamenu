// PizzaGUI - XR controller input (UnityEngine.XR.InputDevices via BNM)
// No BNM types leak through this header, so it is cheap to include anywhere.
#pragma once
#include <cstdint>

namespace pizzagui {

enum class Hand { Left, Right };

enum class BoolFeature {
    PrimaryButton, PrimaryTouch, SecondaryButton, SecondaryTouch,
    GripButton, TriggerButton, MenuButton,
    Primary2DAxisClick, Primary2DAxisTouch,
    Secondary2DAxisClick, Secondary2DAxisTouch
};

enum class FloatFeature { Trigger, Grip };
enum class Vec2Feature  { Primary2DAxis, Secondary2DAxis };

struct Vec2 { float x = 0.f, y = 0.f; };

namespace XRInput {
    // All calls must happen on the Unity main thread, after BNM has loaded.
    // They never throw and return false/0 when the device or API is unavailable.
    bool  GetBool (BoolFeature f,  Hand h);
    float GetFloat(FloatFeature f, Hand h);
    Vec2  GetVec2 (Vec2Feature f,  Hand h);
    void  SendHaptic(Hand h, float amplitude, float durationSeconds, uint32_t channel = 0);

    // Device ids are cached (refreshed every ~250 ms). Call this after a
    // scene change / controller reconnect if you want an immediate refresh.
    void  InvalidateDevices();
}

} // namespace pizzagui
