// PizzaGUI - menu model. Pure C++ (no Unity / BNM). Unit-testable on a host.
#pragma once
#include <deque>
#include <functional>
#include <memory>
#include <optional>
#include <string>
#include <string_view>
#include <vector>
#include "pizzagui/XRInput.hpp"

namespace pizzagui {

enum class ItemType { Toggle, Button, Slider };

struct Item {
    std::string name;
    std::function<std::string()> dynamicName;   // optional: label computed each frame
    std::string tooltip;
    ItemType type = ItemType::Toggle;

    bool enabled = false;                        // toggles
    int  value = 0, minValue = 0, maxValue = 4;  // sliders (inclusive)
    std::vector<std::string> valueNames;         // optional label per slider step (index = value-minValue)

    std::function<void()>    onTick;     // toggles: runs every frame while enabled
    std::function<void()>    onEnable;   // toggles
    std::function<void()>    onDisable;  // toggles
    std::function<void()>    onPress;    // buttons
    std::function<void(int)> onChange;   // sliders

    std::string DisplayName() const;     // name (+ slider suffix), no colour markup
};

class Category {
public:
    explicit Category(std::string name) : name_(std::move(name)) {}
    Category(const Category&) = delete;
    Category& operator=(const Category&) = delete;

    const std::string& Name() const { return name_; }
    Category* Parent() const { return parent_; }
    const std::vector<std::unique_ptr<Item>>& Items() const { return items_; }

    // Returned references stay valid for the lifetime of the menu.
    Item& AddToggle(std::string name, std::function<void()> onTick = {},
                    std::function<void()> onEnable = {}, std::function<void()> onDisable = {});
    Item& AddButton(std::string name, std::function<void()> onPress);
    Item& AddSlider(std::string name, int minValue, int maxValue,
                    std::function<void(int)> onChange = {}, int initial = 0);
    // Adds a button that opens `target`; target gets an automatic Back entry.
    Item& AddSubmenu(std::string name, Category& target);

    Item* Find(std::string_view name) const;

private:
    friend class MenuModel;
    std::string name_;
    Category* parent_ = nullptr;
    std::vector<std::unique_ptr<Item>> items_;
    std::function<void(Category&)> opener_;  // wired up by MenuModel
};

struct Theme {
    std::string title = "Pizza";
    std::string titleMarkup;                         // if set, used verbatim instead of generated title
    std::string titleColorA = "FF9000", titleColorB = "FF5500";
    std::string headerPrefix = "<color=#000000><</color> <color=#FF7736>\xE2\x96\xB2 </color>";
    std::string headerSeparator = "<color=#8585e0>:</color>";
    std::string pageColor = "FF9F73";
    std::string cursorMarker = "<color=#C9A071>\xE2\x86\x92</color> ";
    std::vector<std::string> itemColors = {"FF9000", "FF5500"};   // cycled per item
    std::string toggleOn  = "<color=#8585e0>[</color><color=#a366ff>+</color><color=#8585e0>]</color>";
    std::string toggleOff = "<color=#8585e0>[</color><color=red>-</color><color=#8585e0>]</color>";
    std::string backLabel = "Back";
    std::string prevLabel = "<color=#C9A071><- Back</color>";
    std::string nextLabel = "<color=#C9A071>Next -></color>";
    bool showTooltip = false;
    std::string tooltipColor = "8a8a8a";

    static Theme Pizza();   // the original look
    static Theme Ascii();   // no non-ASCII glyphs (for fonts missing arrows/triangles)
};

struct Binding { Hand hand; BoolFeature feature; };

struct InputScheme {
    Binding modifier{Hand::Left,  BoolFeature::Primary2DAxisClick}; // hold to drive the menu
    Binding select  {Hand::Right, BoolFeature::PrimaryButton};
    Hand        navHand  = Hand::Right;
    Vec2Feature navStick = Vec2Feature::Primary2DAxis;
    float threshold   = 0.7f;
    float repeatDelay = 0.25f;
    bool  requireModifier = true;
    bool  hapticOnSelect  = true;
    float hapticAmplitude = 0.3f, hapticDuration = 0.05f;
    std::optional<Binding> visibilityToggle;   // optional show/hide button (edge triggered)
};

struct NavInput {
    bool modifier = false;   // true when the "hold to use" binding is held
    bool select   = false;
    Vec2 stick;
};

struct NavResult { bool moved = false; bool activated = false; };

class MenuModel {
public:
    MenuModel();

    Theme theme;
    float threshold = 0.7f, repeatDelay = 0.25f;
    int   itemsPerPage = 8;
    bool  requireModifier = true;

    Category& Root() { return *root_; }
    Category& CreateCategory(std::string name);
    Category& Current() { return *current_; }
    void Open(Category& c);
    Item* FindItem(std::string_view name) const;     // searches every category

    void RunToggles();                               // per-frame callbacks of enabled toggles
    NavResult Navigate(const NavInput& in, double nowSeconds);
    std::string BuildText() const;                   // rich-text string for the canvas

    int  PageIndex() const { return page_; }
    int  PageCount() const;
    int  CursorIndex() const { return cursor_; }

    void SetStatus(std::string s) { status_ = std::move(s); }

private:
    struct Entry { enum class Kind { Item, Back, Prev, Next } kind; Item* item = nullptr; int itemIndex = 0; };
    std::vector<Entry> Entries() const;
    void Activate(const Entry& e);
    void Wrap();

    std::deque<Category> categories_;
    Category* root_;
    Category* current_;
    int page_ = 0, cursor_ = 0;
    bool selectLatch_ = false;
    double nextMoveAt_ = 0.0;
    std::string status_;
};

} // namespace pizzagui
