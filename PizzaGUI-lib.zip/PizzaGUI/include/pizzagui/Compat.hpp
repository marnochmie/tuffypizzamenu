// PizzaGUI - Unity version compatibility helpers.
//
// IMPORTANT: BNM-Android selects its IL2CPP struct layouts at COMPILE time (UNITY_VER).
// One binary therefore targets one Unity band. PizzaGUI is built once per band:
//     PIZZAGUI_UNITY=2021.3  -> BNM UNITY_VER 213
//     PIZZAGUI_UNITY=2022.3  -> BNM UNITY_VER 222   (2022.2 - 2022.3)
//     PIZZAGUI_UNITY=6000    -> BNM UNITY_VER 232   (2023.2+ / Unity 6)
// Everything else here (font name, shader fallbacks, API shape) is picked per band.
#pragma once
#include <string>

namespace pizzagui::compat {

struct UnityVersion {
    int  major = 0, minor = 0, patch = 0;
    bool valid = false;
    std::string raw;                       // e.g. "2022.3.21f1"
};

enum class LogLevel { Info = 4, Warn = 5, Error = 6 };
void Log(LogLevel lvl, const char* fmt, ...) __attribute__((format(printf, 2, 3)));

int         BuildTarget();                 // the UNITY_VER this library was compiled for (213 / 222 / 232)
const char* BuildTargetName();             // "2021.3" / "2022.3" / "6000"
const char* BuiltinFontName();             // "Arial.ttf" (<= 2022.1) or "LegacyRuntime.ttf" (>= 2022.2)

UnityVersion RuntimeVersion();             // parsed from Application.unityVersion (cached)
bool         RuntimeMatchesBuild();        // false => you linked the wrong PizzaGUI/BNM variant for this game
void         WarnIfMismatched();           // logs a clear message once

} // namespace pizzagui::compat
