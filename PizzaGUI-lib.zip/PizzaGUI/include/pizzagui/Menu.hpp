// PizzaGUI - in-VR world-space menu for Unity IL2CPP (Android arm64) games, built on BNM-Android.
#pragma once
#include <functional>
#include <string>
#include <string_view>
#include "pizzagui/Model.hpp"

namespace pizzagui {

struct Config {
    Theme       theme;
    InputScheme input;
    int   itemsPerPage = 8;
    bool  startVisible = true;

    // Placement, local to the anchor (defaults = original Pizza GUI: head-locked, lower right)
    float posX = -0.1f, posY = -0.3297f, posZ = 1.6f;
    float scale = 0.005f, width = 300.f, height = 250.f, pixelsPerUnit = 65.f;
    int   textAnchor = 2;          // UnityEngine.TextAnchor: 0 UpperLeft, 1 UpperCenter, 2 UpperRight ...
    bool  bold = true;

    std::string fontName;                         // optional: name of a loaded Font asset to prefer
    std::string shaderName = "GUI/Text Shader";   // falls back to "UI/Default", then "Sprites/Default"

    // Return a UnityEngine.Transform* to parent the menu to. Default: Camera.main's transform.
    std::function<void*()> anchorProvider;
};

namespace Menu {
    // Safe to call early (e.g. from BNM's OnLoaded). No Unity objects are created until Tick().
    void Init(const Config& cfg = {});
    bool IsInitialized();
    void Shutdown();                          // destroys the Unity objects, keeps your items

    Category& Root();
    Category& CreateCategory(std::string name);
    Item*     FindItem(std::string_view name);
    void      Open(Category& c);

    void SetVisible(bool v);
    bool IsVisible();
    void SetStatus(std::string line);         // extra line under the items ("" clears)

    // Call once per frame on the Unity main thread. Duplicate calls within one frame are ignored.
    void Tick();

    // Convenience: hook a per-frame instance method of any game class (Update/LateUpdate/FixedUpdate)
    // and call Tick() from it. Only one hook can be installed. Returns false if the method isn't found.
    bool InstallTickHook(const char* ns, const char* cls, const char* method = "Update");

    std::string DebugText();                  // current rich-text, for logging
}

} // namespace pizzagui
