# Credits
* Original Pizza GUI / BuniModThing menu, input and layout design: **Moony** (the original project asked for credit - keep it).
* [BNM-Android](https://github.com/ByNameModding/BNM-Android) (ByNameModding) and [Dobby](https://github.com/jmpews/Dobby) are third-party and keep their own licenses.
