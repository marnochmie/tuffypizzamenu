# PizzaGUI (lib)

In-VR, head-locked, world-space mod menu for **Unity IL2CPP / Android arm64** (Quest etc.), built on
[BNM-Android](https://github.com/ByNameModding/BNM-Android). Extracted from the Pizza GUI project as a reusable
static library: menu, navigation, XR controller input and Unity UI glue. **No game-specific code.**

Targets: **Unity 2021.3, 2022.3, 6000** (one build per band, see below).

## Why one build per Unity version
BNM picks its IL2CPP struct layouts at *compile time* (`UNITY_VER`). A single binary cannot serve all three.
`PIZZAGUI_UNITY` selects the band and the CMake script sets BNM's `UNITY_VER` to match:

| PIZZAGUI_UNITY | BNM UNITY_VER | covers            | builtin font        |
|----------------|---------------|-------------------|---------------------|
| 2021.3         | 213           | 2021.3.x          | `Arial.ttf`         |
| 2022.3         | 222           | 2022.2 - 2022.3   | `LegacyRuntime.ttf` |
| 6000           | 232           | 2023.2+ / Unity 6 | `LegacyRuntime.ttf` |

At runtime `Application.unityVersion` is read and a loud log line (`adb logcat -s PizzaGUI`) is printed
if you shipped the wrong variant. (Old `Arial.ttf` throws on 2022.2+, which is why the font is chosen by band.)

## Build
```
cmake ... -DPIZZAGUI_UNITY=6000 -DPIZZAGUI_BNM_DIR=<BNM-Android> -DPIZZAGUI_DOBBY_DIR=<Dobby>
```
or `add_subdirectory(PizzaGUI)` in your mod and `target_link_libraries(yourmod PRIVATE PizzaGUI::pizzagui)`.
If your project already defines `BNM` and `dobby` targets they are reused. Note: the script **edits
`UNITY_VER` in your BNM checkout's `GlobalSettings.hpp`** (`-DPIZZAGUI_PATCH_BNM=OFF` to do it yourself).
Gradle: use one product flavor per band passing `-DPIZZAGUI_UNITY=...` in `externalNativeBuild.cmake.arguments`.
Needs C++20.

## One-command arm64 build (Unity 2022.3)
```
ANDROID_NDK_HOME=... BNM_DIR=.../BNM-Android DOBBY_DIR=.../Dobby ./build_android.sh 2022.3
```
Outputs `dist/2022.3/`: `libpizzagui.a` (use this), `libBNM.a`, `libdobby.a`, `libpizzagui.so`, `libexamplemod.so`.
Needs NDK r25+, CMake 3.18+, Ninja. Link the static lib into your own mod `.so`; a standalone `libpizzagui.so`
duplicates BNM if your mod also links it.

## Use
```cpp
#include <pizzagui/PizzaGUI.hpp>
using namespace pizzagui;

Menu::Init();                                   // from BNM OnLoaded
Category& c = Menu::CreateCategory("Tools");
Menu::Root().AddSubmenu("Tools", c);
c.AddToggle("Thing", onTickWhileOn, onEnable, onDisable);
c.AddButton("Do it", [] { ... });
c.AddSlider("Level", 0, 4, [](int v) { ... }, 2).valueNames = {"a","b","c","d","e"};
Menu::InstallTickHook("", "YourGameClass", "Update");   // or call Menu::Tick() yourself once per frame
```
See `examples/basic`. Defaults match the original: hold **left stick click**, **right stick** moves/adjusts,
**right A/X (PrimaryButton)** selects. Everything is configurable via `Config` / `InputScheme` / `Theme`
(`Theme::Ascii()` if your font lacks `→ ▲`; optional show/hide button via `input.visibilityToggle`).

## What changed vs. the original
* Dynamic categories/submenus/paging instead of hard-coded index tables; stable item references.
* Dynamic labels (`item.dynamicName`) instead of mutating buttons from mods.
* Menu is rebuilt/re-parented automatically if `Camera.main` or the scene changes (the original built once and
  hard-wired the game's head collider).
* XR input: cached device ids, cached method lookups, and a fix for the extern fallback (it used the `_float`
  entry point for bool and Vector2).
* Shader fallbacks (`GUI/Text Shader` -> `UI/Default` -> `Sprites/Default`) since built-in shaders can be stripped.
* Throwing mod callbacks are contained; per-frame dedupe so hooking a multi-instance `Update` ticks once.

## Not included on purpose
The original's game-specific mods (`Exploits.hpp`, `Mods.hpp`, the game SDK dump, Photon/OpenSSL bits) are not part
of a GUI library. Register your own mods through the API above.

## Tested / not tested
* `tests/model_test.cpp` (navigation, paging, sliders, submenus, rendering): **passes on a host compiler**.
* The Unity/BNM sources were **syntax-checked against the real BNM headers** but **not compiled with the NDK or run on a headset**
  (no NDK/device here). Expect to fix small things on first device run; logcat tag is `PizzaGUI`.
* Requires `UnityEngine.UI` (uGUI) and the XR module not to be stripped from the target game.

Credits: see NOTICE.md.
