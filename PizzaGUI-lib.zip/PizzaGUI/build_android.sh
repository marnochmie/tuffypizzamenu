#!/usr/bin/env bash
# Builds PizzaGUI for arm64-v8a / Unity 2022.3 (BNM UNITY_VER 222).
#   ANDROID_NDK_HOME=/path/to/ndk BNM_DIR=/path/BNM-Android DOBBY_DIR=/path/Dobby ./build_android.sh [2021.3|2022.3|6000]
# Output: dist/<unity>/libpizzagui.a, libBNM.a, libdobby.a, libpizzagui.so, libexamplemod.so
set -euo pipefail
UNITY="${1:-2022.3}"
: "${ANDROID_NDK_HOME:?set ANDROID_NDK_HOME}" "${BNM_DIR:?set BNM_DIR}" "${DOBBY_DIR:?set DOBBY_DIR}"
HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="$HERE/build/$UNITY"; DIST="$HERE/dist/$UNITY"
mkdir -p "$DIST"

cmake -S "$HERE/examples/basic" -B "$OUT" -G Ninja \
  -DCMAKE_TOOLCHAIN_FILE="$ANDROID_NDK_HOME/build/cmake/android.toolchain.cmake" \
  -DANDROID_ABI=arm64-v8a -DANDROID_PLATFORM=android-24 -DANDROID_STL=c++_static \
  -DCMAKE_BUILD_TYPE=Release \
  -DPIZZAGUI_UNITY="$UNITY" -DPIZZAGUI_BNM_DIR="$BNM_DIR" -DPIZZAGUI_DOBBY_DIR="$DOBBY_DIR" \
  -DPIZZAGUI_BUILD_SHARED=ON
cmake --build "$OUT"

find "$OUT" \( -name 'libpizzagui.a' -o -name 'libpizzagui.so' -o -name 'libexamplemod.so' -o -name 'libBNM.a' -o -name 'libdobby.a' \) -exec cp -v {} "$DIST/" \;
echo "done -> $DIST"
