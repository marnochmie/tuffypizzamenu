#include "pizzagui/XRInput.hpp"
#include "pizzagui/Compat.hpp"

#include <chrono>
#include <string>

#include <BNM/Class.hpp>
#include <BNM/Method.hpp>
#include <BNM/Utils.hpp>
#include <BNM/BasicMonoStructures.hpp>

namespace pizzagui {
namespace {

using Clock = std::chrono::steady_clock;
using MStr  = BNM::Structures::Mono::String;

// Layout of UnityEngine.XR.InputDevice (2019.x .. 6000): { ulong m_DeviceId; bool m_Initialized; }
struct XRDevice { uint64_t id; bool initialized; };

struct DeviceCache {
    uint64_t id[2] = {0, 0};
    bool     valid[2] = {false, false};
    Clock::time_point stamp{};
    bool     stamped = false;
} g_dev;

constexpr int kNodeLeftHand = 4, kNodeRightHand = 5;   // UnityEngine.XR.XRNode
constexpr auto kRefresh = std::chrono::milliseconds(250);

BNM::Class& InputDevicesClass() {
    static BNM::Class c("UnityEngine.XR", "InputDevices");
    return c;
}

bool RefreshDevices(bool force) {
    const auto now = Clock::now();
    if (!force && g_dev.stamped && now - g_dev.stamp < kRefresh)
        return g_dev.valid[0] || g_dev.valid[1];

    BNM::Method<XRDevice> get = InputDevicesClass().GetMethod("GetDeviceAtXRNode", 1);
    if (!get.IsValid()) {
        static bool warned = false;
        if (!warned) { warned = true; compat::Log(compat::LogLevel::Error, "UnityEngine.XR.InputDevices.GetDeviceAtXRNode not found (XR module stripped?)"); }
        return false;
    }
    const XRDevice l = get(kNodeLeftHand);
    const XRDevice r = get(kNodeRightHand);
    g_dev.id[0] = l.id;  g_dev.valid[0] = l.id != ~0ull;
    g_dev.id[1] = r.id;  g_dev.valid[1] = r.id != ~0ull;
    g_dev.stamp = now;   g_dev.stamped = true;
    return g_dev.valid[0] || g_dev.valid[1];
}

bool DeviceFor(Hand h, uint64_t& id) {
    RefreshDevices(false);
    const int i = h == Hand::Left ? 0 : 1;
    id = g_dev.id[i];
    return g_dev.valid[i];
}

// ---- TryGetFeatureValue_{bool,float,Vector2f}(ulong, string, out T) ------------------------
struct TryFn {
    const char*        name;
    const char*        externName;
    BNM::Method<bool>  method;
    void*              ext = nullptr;
    int                attempts = 0;
};

template <typename T>
bool Query(TryFn& f, uint64_t dev, const char* usage, T* out) {
    if (!f.method.IsValid() && !f.ext && f.attempts < 5) {
        ++f.attempts;
        f.method = InputDevicesClass().GetMethod(f.name, 3);
        if (!f.method.IsValid()) f.ext = BNM::GetExternMethod(f.externName);
        if (!f.method.IsValid() && !f.ext && f.attempts == 5)
            compat::Log(compat::LogLevel::Error, "XR input API %s not found", f.name);
    }
    MStr* key = BNM::CreateMonoString(usage);
    if (f.method.IsValid()) return f.method(dev, key, out);
    if (f.ext)              return reinterpret_cast<bool (*)(uint64_t, MStr*, T*)>(f.ext)(dev, key, out);
    return false;
}

struct Vec2f { float x, y; };

TryFn g_tryBool  {"TryGetFeatureValue_bool",     "UnityEngine.XR.InputDevices::TryGetFeatureValue_bool"};
TryFn g_tryFloat {"TryGetFeatureValue_float",    "UnityEngine.XR.InputDevices::TryGetFeatureValue_float"};
TryFn g_tryVec2  {"TryGetFeatureValue_Vector2f", "UnityEngine.XR.InputDevices::TryGetFeatureValue_Vector2f"};

const char* Name(BoolFeature f) {
    switch (f) {
        case BoolFeature::PrimaryButton:         return "PrimaryButton";
        case BoolFeature::PrimaryTouch:          return "PrimaryTouch";
        case BoolFeature::SecondaryButton:       return "SecondaryButton";
        case BoolFeature::SecondaryTouch:        return "SecondaryTouch";
        case BoolFeature::GripButton:            return "GripButton";
        case BoolFeature::TriggerButton:         return "TriggerButton";
        case BoolFeature::MenuButton:            return "MenuButton";
        case BoolFeature::Primary2DAxisClick:    return "Primary2DAxisClick";
        case BoolFeature::Primary2DAxisTouch:    return "Primary2DAxisTouch";
        case BoolFeature::Secondary2DAxisClick:  return "Secondary2DAxisClick";
        case BoolFeature::Secondary2DAxisTouch:  return "Secondary2DAxisTouch";
    }
    return "";
}
const char* Name(FloatFeature f) { return f == FloatFeature::Trigger ? "Trigger" : "Grip"; }
const char* Name(Vec2Feature f)  { return f == Vec2Feature::Primary2DAxis ? "Primary2DAxis" : "Secondary2DAxis"; }

} // namespace

namespace XRInput {

bool GetBool(BoolFeature f, Hand h) {
    uint64_t dev;
    if (!DeviceFor(h, dev)) return false;
    bool v = false;
    return Query(g_tryBool, dev, Name(f), &v) && v;
}

float GetFloat(FloatFeature f, Hand h) {
    uint64_t dev;
    if (!DeviceFor(h, dev)) return 0.f;
    float v = 0.f;
    return Query(g_tryFloat, dev, Name(f), &v) ? v : 0.f;
}

Vec2 GetVec2(Vec2Feature f, Hand h) {
    uint64_t dev;
    if (!DeviceFor(h, dev)) return {};
    Vec2f v{0.f, 0.f};
    if (!Query(g_tryVec2, dev, Name(f), &v)) return {};
    return {v.x, v.y};
}

void SendHaptic(Hand h, float amplitude, float duration, uint32_t channel) {
    uint64_t dev;
    if (!DeviceFor(h, dev)) return;
    static BNM::Method<void> m;
    static void* ext = nullptr;
    if (!m.IsValid() && !ext) {
        m = InputDevicesClass().GetMethod("SendHapticImpulse", 4);
        if (!m.IsValid()) ext = BNM::GetExternMethod("UnityEngine.XR.InputDevices::SendHapticImpulse");
    }
    if (m.IsValid())      m(dev, channel, amplitude, duration);
    else if (ext)         reinterpret_cast<void (*)(uint64_t, uint32_t, float, float)>(ext)(dev, channel, amplitude, duration);
}

void InvalidateDevices() { RefreshDevices(true); }

} // namespace XRInput
} // namespace pizzagui
