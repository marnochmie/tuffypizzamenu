#include "pizzagui/Menu.hpp"
#include "pizzagui/Compat.hpp"

#include <chrono>
#include <cmath>

#include <BNM/Class.hpp>
#include <BNM/Method.hpp>
#include <BNM/MethodBase.hpp>
#include <BNM/Utils.hpp>
#include <BNM/UnityStructures.hpp>
#include <BNM/BasicMonoStructures.hpp>
#include <BNM/ComplexMonoStructures.hpp>
#include <BNM/UnityStructures/Vector2.hpp>
#include <BNM/UnityStructures/Vector3.hpp>

namespace pizzagui {
namespace {

using namespace BNM::Structures::Unity;
using Obj  = BNM::IL2CPP::Il2CppObject;
using MStr = BNM::Structures::Mono::String;
using compat::Log;
using compat::LogLevel;

bool Alive(void* o) { return o && reinterpret_cast<BNM::UnityEngine::Object*>(o)->Alive(); }

// Looks the method up on its declaring class and calls it. Logs (once per name) and returns R{} if missing.
template <typename R, typename... A>
R Call(const char* ns, const char* cls, const char* name, int argc, void* inst, A... a) {
    BNM::Method<R> m = BNM::Class(ns, cls).GetMethod(name, argc);
    if (!m.IsValid()) { Log(LogLevel::Error, "missing %s.%s::%s", ns, cls, name); return R(); }
    if (inst) m[inst];
    return m(a...);
}

double NowSeconds() {
    using namespace std::chrono;
    return duration<double>(steady_clock::now().time_since_epoch()).count();
}

struct UI {
    void* go = nullptr;
    void* rect = nullptr;
    void* text = nullptr;
    void* anchor = nullptr;
    std::string last;
    bool dirty = true;
};

struct State {
    bool init = false;
    Config cfg;
    MenuModel model;
    UI ui;
    bool visible = true;
    bool visLatch = false;
    double nextBuildAt = 0;
    int lastFrame = -1;
} g;

void* DefaultAnchor() {
    void* cam = Call<void*>("UnityEngine", "Camera", "get_main", 0, nullptr);
    if (!Alive(cam)) return nullptr;
    return Call<void*>("UnityEngine", "Component", "get_transform", 0, cam);
}

void* FindFont(const std::string& wanted) {
    BNM::Class fontC("UnityEngine", "Font");
    if (!fontC.GetClass()) return nullptr;
    if (!wanted.empty()) {
        auto* arr = Call<BNM::Structures::Mono::Array<Obj*>*>("UnityEngine", "Resources", "FindObjectsOfTypeAll", 1, nullptr, fontC.GetMonoType());
        if (arr) for (Obj* f : arr->ToVector()) {
            MStr* n = Call<MStr*>("UnityEngine", "Object", "get_name", 0, f);
            if (n && n->str() == wanted) return f;
        }
        Log(LogLevel::Warn, "font '%s' not found, using builtin", wanted.c_str());
    }
    void* f = Call<void*>("UnityEngine", "Resources", "GetBuiltinResource", 2, nullptr, fontC.GetMonoType(),
                          BNM::CreateMonoString(compat::BuiltinFontName()));
    return Alive(f) ? f : nullptr;
}

void* MakeMaterial(const Config& cfg) {
    const char* names[] = {cfg.shaderName.c_str(), "UI/Default", "Sprites/Default"};
    for (int i = 0; i < 3; ++i) {
        if (!*names[i]) continue;
        void* sh = Call<void*>("UnityEngine", "Shader", "Find", 1, nullptr, BNM::CreateMonoString(names[i]));
        if (!Alive(sh)) continue;
        if (i > 0) Log(LogLevel::Warn, "shader '%s' unavailable, using '%s'", cfg.shaderName.c_str(), names[i]);
        return BNM::Class("UnityEngine", "Material").CreateNewObjectParameters(sh);
    }
    Log(LogLevel::Error, "no usable GUI shader found; menu will use the default UI material");
    return nullptr;
}

void Destroy() {
    if (Alive(g.ui.go)) Call<void>("UnityEngine", "Object", "Destroy", 1, nullptr, g.ui.go);
    g.ui = UI{};
}

bool Build(void* anchor) {
    const Config& c = g.cfg;
    BNM::Class canvasC("UnityEngine", "Canvas"), textC("UnityEngine.UI", "Text"), scalerC("UnityEngine.UI", "CanvasScaler");
    if (!canvasC.GetClass() || !textC.GetClass()) {
        Log(LogLevel::Error, "UnityEngine.UI (uGUI) is not present in this game - cannot draw the menu");
        return false;
    }

    Obj* go = BNM::Class("UnityEngine", "GameObject").CreateNewObjectParameters(BNM::CreateMonoString("[PizzaGUI]"));
    if (!go) return false;

    void* canvas = Call<void*>("UnityEngine", "GameObject", "AddComponent", 1, go, canvasC.GetMonoType());
    Call<void>("UnityEngine", "Canvas", "set_renderMode", 1, canvas, 2 /* WorldSpace */);

    void* rect = Call<void*>("UnityEngine", "GameObject", "get_transform", 0, go);   // RectTransform once a Canvas exists
    void* text = Call<void*>("UnityEngine", "GameObject", "AddComponent", 1, go, textC.GetMonoType());
    if (!text || !rect) { Call<void>("UnityEngine", "Object", "Destroy", 1, nullptr, go); return false; }

    Call<void>("UnityEngine.UI", "Text", "set_supportRichText", 1, text, true);
    if (void* mat = MakeMaterial(c)) Call<void>("UnityEngine.UI", "Graphic", "set_material", 1, text, mat);
    if (void* font = FindFont(c.fontName)) Call<void>("UnityEngine.UI", "Text", "set_font", 1, text, font);

    Call<void>("UnityEngine", "Transform", "SetParent", 2, rect, anchor, false);
    Call<void>("UnityEngine", "Transform", "set_localEulerAngles", 1, rect, Vector3(0, 0, 0));
    Call<void>("UnityEngine", "RectTransform", "set_sizeDelta", 1, rect, Vector2(c.width, c.height));
    Call<void>("UnityEngine", "Transform", "set_localPosition", 1, rect, Vector3(c.posX, c.posY, c.posZ));
    Call<void>("UnityEngine", "Transform", "set_localScale", 1, rect, Vector3(c.scale, c.scale, c.scale));

    if (scalerC.GetClass()) {
        void* scaler = Call<void*>("UnityEngine", "GameObject", "AddComponent", 1, go, scalerC.GetMonoType());
        if (scaler) Call<void>("UnityEngine.UI", "CanvasScaler", "set_dynamicPixelsPerUnit", 1, scaler, c.pixelsPerUnit);
    }
    Call<void>("UnityEngine.UI", "Text", "set_fontStyle", 1, text, c.bold ? 1 : 0);
    Call<void>("UnityEngine.UI", "Text", "set_alignment", 1, text, c.textAnchor);
    Call<void>("UnityEngine", "GameObject", "SetActive", 1, go, g.visible);

    g.ui = UI{go, rect, text, anchor, "", true};
    return true;
}

void EnsureUI() {
    void* anchor = g.cfg.anchorProvider ? g.cfg.anchorProvider() : DefaultAnchor();
    if (!Alive(anchor)) return;

    if (!Alive(g.ui.go)) {
        const double now = NowSeconds();
        if (now < g.nextBuildAt) return;       // don't hammer a failing build
        g.nextBuildAt = now + 1.0;
        g.ui = UI{};
        if (Build(anchor)) Log(LogLevel::Info, "menu built (Unity target %s)", compat::BuildTargetName());
    } else if (anchor != g.ui.anchor) {        // Camera.main changed (scene load / rig swap)
        Call<void>("UnityEngine", "Transform", "SetParent", 2, g.ui.rect, anchor, false);
        g.ui.anchor = anchor;
    }
}

int FrameCount() {
    static BNM::Method<int> m;
    static bool tried = false;
    if (!tried) { tried = true; m = BNM::Class("UnityEngine", "Time").GetMethod("get_frameCount", 0); }
    return m.IsValid() ? m() : -1;
}

NavInput Poll() {
    const InputScheme& s = g.cfg.input;
    NavInput in;
    in.modifier = XRInput::GetBool(s.modifier.feature, s.modifier.hand);
    if (in.modifier || !s.requireModifier) {
        in.select = XRInput::GetBool(s.select.feature, s.select.hand);
        in.stick  = XRInput::GetVec2(s.navStick, s.navHand);
    } else {
        in.select = false;   // keeps the model's latch honest
    }
    return in;
}

// ---- tick hook -----------------------------------------------------------------------------
void (*g_origTick)(void*) = nullptr;
void HookedTick(void* inst) {
    if (g_origTick) g_origTick(inst);
    Menu::Tick();
}

} // namespace

namespace Menu {

void Init(const Config& cfg) {
    g.cfg = cfg;
    g.model.theme = cfg.theme;
    g.model.itemsPerPage = cfg.itemsPerPage;
    g.model.threshold = cfg.input.threshold;
    g.model.repeatDelay = cfg.input.repeatDelay;
    g.model.requireModifier = cfg.input.requireModifier;
    g.visible = cfg.startVisible;
    g.init = true;
}

bool IsInitialized() { return g.init; }

void Shutdown() { Destroy(); }

Category& Root() { return g.model.Root(); }
Category& CreateCategory(std::string n) { return g.model.CreateCategory(std::move(n)); }
Item* FindItem(std::string_view n) { return g.model.FindItem(n); }
void Open(Category& c) { g.model.Open(c); }

void SetVisible(bool v) {
    g.visible = v;
    if (Alive(g.ui.go)) Call<void>("UnityEngine", "GameObject", "SetActive", 1, g.ui.go, v);
}
bool IsVisible() { return g.visible; }
void SetStatus(std::string s) { g.model.SetStatus(std::move(s)); }

void Tick() {
    if (!g.init) return;
    const int frame = FrameCount();
    if (frame >= 0 && frame == g.lastFrame) return;
    g.lastFrame = frame;

    compat::WarnIfMismatched();
    g.model.RunToggles();                       // mods keep running while the menu is hidden

    const InputScheme& s = g.cfg.input;
    if (s.visibilityToggle) {
        const bool down = XRInput::GetBool(s.visibilityToggle->feature, s.visibilityToggle->hand);
        if (down && !g.visLatch) SetVisible(!g.visible);
        g.visLatch = down;
    }

    if (g.visible) {
        const NavResult r = g.model.Navigate(Poll(), NowSeconds());
        if (r.activated && s.hapticOnSelect)
            XRInput::SendHaptic(s.select.hand, s.hapticAmplitude, s.hapticDuration);
    }

    EnsureUI();
    if (!Alive(g.ui.text)) return;

    std::string t = g.model.BuildText();
    if (g.ui.dirty || t != g.ui.last) {
        Call<void>("UnityEngine.UI", "Text", "set_text", 1, g.ui.text, BNM::CreateMonoString(t));
        g.ui.last = std::move(t);
        g.ui.dirty = false;
    }
}

bool InstallTickHook(const char* ns, const char* cls, const char* method) {
    if (g_origTick) return false;
    BNM::MethodBase target = BNM::Class(ns, cls).GetMethod(method, 0);
    if (!target.IsValid()) { Log(LogLevel::Error, "tick hook target %s.%s::%s not found", ns, cls, method); return false; }
    return BNM::InvokeHook(target, HookedTick, g_origTick);
}

std::string DebugText() { return g.model.BuildText(); }

} // namespace Menu
} // namespace pizzagui
