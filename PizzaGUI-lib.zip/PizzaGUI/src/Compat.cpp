#include "pizzagui/Compat.hpp"

#include <cstdarg>
#include <cstdio>

#include <BNM/Class.hpp>
#include <BNM/Method.hpp>
#include <BNM/Utils.hpp>
#include <BNM/BasicMonoStructures.hpp>

#ifdef __ANDROID__
#include <android/log.h>
#endif

#ifndef PIZZAGUI_UNITY_VER
#error "PIZZAGUI_UNITY_VER is not defined. Build through the provided CMakeLists.txt (set PIZZAGUI_UNITY)."
#endif

namespace pizzagui::compat {

void Log(LogLevel lvl, const char* fmt, ...) {
    char buf[512];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
#ifdef __ANDROID__
    __android_log_print(static_cast<int>(lvl), "PizzaGUI", "%s", buf);
#else
    std::fprintf(stderr, "[PizzaGUI] %s\n", buf);
#endif
}

int BuildTarget() { return PIZZAGUI_UNITY_VER; }

const char* BuildTargetName() {
    switch (PIZZAGUI_UNITY_VER) {
        case 213: return "2021.3";
        case 222: return "2022.3";
        case 232: return "6000";
        default:  return "custom";
    }
}

const char* BuiltinFontName() {
    // Unity 2022.2 removed the builtin "Arial.ttf"; asking for it throws ArgumentException,
    // which would unwind through native frames and crash the game. Choose by build band, not by trial.
#if PIZZAGUI_UNITY_VER >= 222
    return "LegacyRuntime.ttf";
#else
    return "Arial.ttf";
#endif
}

UnityVersion RuntimeVersion() {
    static UnityVersion v;
    static bool done = false;
    if (done) return v;

    BNM::Class app("UnityEngine", "Application");
    BNM::Method<BNM::Structures::Mono::String*> get = app.GetMethod("get_unityVersion");
    BNM::Structures::Mono::String* s = nullptr;
    if (get.IsValid()) {
        s = get();
    } else if (auto ext = (BNM::Structures::Mono::String*(*)())BNM::GetExternMethod("UnityEngine.Application::get_unityVersion")) {
        s = ext();
    }
    if (!s) return v;           // not loaded yet / unavailable: don't cache, try again later

    v.raw = s->str();
    v.valid = std::sscanf(v.raw.c_str(), "%d.%d.%d", &v.major, &v.minor, &v.patch) >= 2;
    done = true;
    return v;
}

bool RuntimeMatchesBuild() {
    const UnityVersion v = RuntimeVersion();
    if (!v.valid) return true;  // can't tell -> don't cry wolf
    switch (PIZZAGUI_UNITY_VER) {
        case 213: return v.major == 2021 && v.minor == 3;
        case 222: return v.major == 2022 && v.minor >= 2;
        case 232: return v.major >= 6000 || (v.major == 2023 && v.minor >= 2);
        default:  return true;
    }
}

void WarnIfMismatched() {
    static bool warned = false;
    if (warned) return;
    const UnityVersion v = RuntimeVersion();
    if (!v.valid) return;
    warned = true;
    if (RuntimeMatchesBuild())
        Log(LogLevel::Info, "built for Unity %s, running %s - ok", BuildTargetName(), v.raw.c_str());
    else
        Log(LogLevel::Error, "BUILT FOR UNITY %s BUT GAME RUNS %s. BNM struct layouts will not match; "
                             "rebuild with the matching PIZZAGUI_UNITY.", BuildTargetName(), v.raw.c_str());
}

} // namespace pizzagui::compat
