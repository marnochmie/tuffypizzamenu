#include "pizzagui/Model.hpp"

#include <algorithm>
#include <cctype>
#include <cmath>

namespace pizzagui {

// ---------------------------------------------------------------- Item ----
std::string Item::DisplayName() const {
    std::string n = dynamicName ? dynamicName() : name;
    if (type != ItemType::Slider) return n;

    const int idx = value - minValue;
    if (idx >= 0 && idx < static_cast<int>(valueNames.size()))
        n += " (" + valueNames[idx] + ")";
    n += " [" + std::to_string(idx + 1) + "/" + std::to_string(maxValue - minValue + 1) + "]";
    return n;
}

// ------------------------------------------------------------ Category ----
Item& Category::AddToggle(std::string name, std::function<void()> onTick,
                          std::function<void()> onEnable, std::function<void()> onDisable) {
    auto it = std::make_unique<Item>();
    it->name = std::move(name);
    it->type = ItemType::Toggle;
    it->onTick = std::move(onTick);
    it->onEnable = std::move(onEnable);
    it->onDisable = std::move(onDisable);
    items_.push_back(std::move(it));
    return *items_.back();
}

Item& Category::AddButton(std::string name, std::function<void()> onPress) {
    auto it = std::make_unique<Item>();
    it->name = std::move(name);
    it->type = ItemType::Button;
    it->onPress = std::move(onPress);
    items_.push_back(std::move(it));
    return *items_.back();
}

Item& Category::AddSlider(std::string name, int minValue, int maxValue,
                          std::function<void(int)> onChange, int initial) {
    if (maxValue < minValue) std::swap(minValue, maxValue);
    auto it = std::make_unique<Item>();
    it->name = std::move(name);
    it->type = ItemType::Slider;
    it->minValue = minValue;
    it->maxValue = maxValue;
    it->value = std::clamp(initial, minValue, maxValue);
    it->onChange = std::move(onChange);
    items_.push_back(std::move(it));
    return *items_.back();
}

Item& Category::AddSubmenu(std::string name, Category& target) {
    if (!target.parent_ && &target != this) target.parent_ = this;
    Category* t = &target;
    Item& it = AddButton(std::move(name), [this, t]() { if (opener_) opener_(*t); });
    return it;
}

Item* Category::Find(std::string_view name) const {
    for (auto& i : items_)
        if (i->name == name) return i.get();
    return nullptr;
}

// --------------------------------------------------------------- Theme ----
Theme Theme::Pizza() { return Theme{}; }

Theme Theme::Ascii() {
    Theme t;
    t.headerPrefix = "";
    t.cursorMarker = "<color=#C9A071>></color> ";
    t.prevLabel = "<color=#C9A071>[Prev]</color>";
    t.nextLabel = "<color=#C9A071>[Next]</color>";
    return t;
}

// ----------------------------------------------------------- MenuModel ----
namespace {

// Splits UTF-8 into code point strings so title colouring never cuts a glyph in half.
std::vector<std::string> SplitUtf8(const std::string& s) {
    std::vector<std::string> out;
    for (size_t i = 0; i < s.size();) {
        unsigned char c = static_cast<unsigned char>(s[i]);
        size_t len = c < 0x80 ? 1 : (c >> 5) == 0x6 ? 2 : (c >> 4) == 0xE ? 3 : (c >> 3) == 0x1E ? 4 : 1;
        len = std::min(len, s.size() - i);
        out.emplace_back(s.substr(i, len));
        i += len;
    }
    return out;
}

std::string Colored(const std::string& hexOrName, const std::string& text) {
    const bool named = !hexOrName.empty() && hexOrName[0] != '#' &&
                       !std::all_of(hexOrName.begin(), hexOrName.end(), [](unsigned char c) { return std::isxdigit(c); });
    return "<color=" + std::string(named ? "" : "#") + hexOrName + ">" + text + "</color>";
}

} // namespace

MenuModel::MenuModel() {
    categories_.emplace_back("Home");
    root_ = current_ = &categories_.back();
    root_->opener_ = [this](Category& c) { Open(c); };
}

Category& MenuModel::CreateCategory(std::string name) {
    categories_.emplace_back(std::move(name));
    Category& c = categories_.back();
    c.opener_ = [this](Category& t) { Open(t); };
    return c;
}

void MenuModel::Open(Category& c) {
    current_ = &c;
    page_ = 0;
    cursor_ = 0;
}

Item* MenuModel::FindItem(std::string_view name) const {
    for (auto& c : categories_)
        if (Item* i = c.Find(name)) return i;
    return nullptr;
}

int MenuModel::PageCount() const {
    const int per = std::max(1, itemsPerPage);
    const int n = static_cast<int>(current_->items_.size());
    return std::max(1, (n + per - 1) / per);
}

void MenuModel::RunToggles() {
    for (auto& c : categories_)
        for (auto& i : c.items_)
            if (i->type == ItemType::Toggle && i->enabled && i->onTick) {
                try { i->onTick(); } catch (...) { /* a bad mod must not take the menu down */ }
            }
}

std::vector<MenuModel::Entry> MenuModel::Entries() const {
    std::vector<Entry> e;
    if (current_->parent_) e.push_back({Entry::Kind::Back, nullptr, 0});

    const int per = std::max(1, itemsPerPage);
    const int total = static_cast<int>(current_->items_.size());
    const int pages = PageCount();
    const int p = std::clamp(page_, 0, pages - 1);
    for (int i = p * per; i < std::min(total, p * per + per); ++i)
        e.push_back({Entry::Kind::Item, current_->items_[i].get(), i});

    if (pages > 1) {
        e.push_back({Entry::Kind::Prev, nullptr, 0});
        e.push_back({Entry::Kind::Next, nullptr, 0});
    }
    return e;
}

void MenuModel::Wrap() {
    const int pages = PageCount();
    if (page_ < 0) page_ = pages - 1;
    if (page_ >= pages) page_ = 0;

    const int n = static_cast<int>(Entries().size());
    if (n == 0) { cursor_ = 0; return; }
    if (cursor_ < 0) cursor_ = n - 1;
    if (cursor_ >= n) cursor_ = 0;
}

void MenuModel::Activate(const Entry& e) {
    switch (e.kind) {
        case Entry::Kind::Back:
            if (current_->parent_) Open(*current_->parent_);
            return;
        case Entry::Kind::Prev:
        case Entry::Kind::Next: {
            const int pages = PageCount();
            page_ = (page_ + (e.kind == Entry::Kind::Next ? 1 : -1) + pages) % pages;
            // keep the cursor on the same Prev/Next entry so holding select flips pages
            auto entries = Entries();
            for (int i = 0; i < static_cast<int>(entries.size()); ++i)
                if (entries[i].kind == e.kind) { cursor_ = i; break; }
            return;
        }
        case Entry::Kind::Item:
            break;
    }

    Item* it = e.item;
    if (!it) return;
    try {
        if (it->type == ItemType::Toggle) {
            it->enabled = !it->enabled;
            if (it->enabled && it->onEnable) it->onEnable();
            if (!it->enabled && it->onDisable) it->onDisable();
        } else if (it->type == ItemType::Button) {
            if (it->onPress) it->onPress();
        }
    } catch (...) {}
}

NavResult MenuModel::Navigate(const NavInput& in, double now) {
    NavResult r;
    const bool active = in.modifier || !requireModifier;

    Wrap();
    auto entries = Entries();

    if (active && !entries.empty()) {
        // one activation per press (latch is cleared when select is released)
        if (in.select && !selectLatch_) {
            if (cursor_ >= 0 && cursor_ < static_cast<int>(entries.size())) {
                Activate(entries[cursor_]);
                r.activated = true;
            }
            selectLatch_ = true;
            Wrap();
            entries = Entries();
        }

        if (now >= nextMoveAt_) {
            const bool up = in.stick.y >= threshold, down = in.stick.y <= -threshold;
            const bool right = in.stick.x >= threshold, left = in.stick.x <= -threshold;

            if (up)        { --cursor_; r.moved = true; }
            else if (down) { ++cursor_; r.moved = true; }
            else if (left || right) {
                Wrap();
                entries = Entries();
                if (cursor_ >= 0 && cursor_ < static_cast<int>(entries.size())) {
                    Item* it = entries[cursor_].item;
                    if (it && it->type == ItemType::Slider) {
                        const int before = it->value;
                        it->value = std::clamp(it->value + (right ? 1 : -1), it->minValue, it->maxValue);
                        if (it->value != before) {
                            r.moved = true;
                            if (it->onChange) { try { it->onChange(it->value); } catch (...) {} }
                        }
                    }
                }
            }
            if (up || down || left || right) nextMoveAt_ = now + repeatDelay;
        }
    }
    if (!in.select) selectLatch_ = false;

    Wrap();
    return r;
}

std::string MenuModel::BuildText() const {
    // const-correct wrapper: Wrap() only touches cursor/page which are mutable state of the view
    const_cast<MenuModel*>(this)->Wrap();

    std::string title = theme.titleMarkup;
    if (title.empty()) {
        const auto glyphs = SplitUtf8(theme.title);
        for (size_t i = 0; i < glyphs.size(); ++i)
            title += Colored(i % 2 == 0 ? theme.titleColorA : theme.titleColorB, glyphs[i]);
    }

    std::string out = theme.headerPrefix + title + theme.headerSeparator +
                      Colored(theme.pageColor, "[" + std::to_string(page_ + 1) + "/" + std::to_string(PageCount()) + "]") + "\n";

    const auto entries = Entries();
    const auto& colors = theme.itemColors;
    auto colorAt = [&](int i) -> std::string { return colors.empty() ? std::string("FFFFFF") : colors[static_cast<size_t>(i) % colors.size()]; };

    for (int i = 0; i < static_cast<int>(entries.size()); ++i) {
        const Entry& e = entries[i];
        std::string label;
        switch (e.kind) {
            case Entry::Kind::Back: label = "<b>" + Colored(colorAt(0), theme.backLabel) + "</b>"; break;
            case Entry::Kind::Prev: label = theme.prevLabel; break;
            case Entry::Kind::Next: label = theme.nextLabel; break;
            case Entry::Kind::Item: {
                const std::string name = e.item->DisplayName();
                label = name.find('<') != std::string::npos ? name   // caller supplied own markup
                                                              : "<b>" + Colored(colorAt(e.itemIndex), name) + "</b>";
                if (e.item->type == ItemType::Toggle) label += " " + (e.item->enabled ? theme.toggleOn : theme.toggleOff);
                break;
            }
        }
        out += (i == cursor_ ? theme.cursorMarker : std::string()) + label + "\n";
    }

    if (theme.showTooltip && cursor_ >= 0 && cursor_ < static_cast<int>(entries.size())) {
        const Item* it = entries[cursor_].item;
        if (it && !it->tooltip.empty()) out += Colored(theme.tooltipColor, "<size=70%>" + it->tooltip + "</size>") + "\n";
    }
    if (!status_.empty()) out += status_ + "\n";
    return out;
}

} // namespace pizzagui
