// Minimal mod: builds a menu and drives it from a game's per-frame method.
#include <jni.h>
#include <BNM/Loading.hpp>
#include <pizzagui/PizzaGUI.hpp>

using namespace pizzagui;

static void OnLoaded() {
    Config cfg;
    cfg.theme.title = "MyMenu";           // Theme::Ascii() if your font lacks arrows / triangles
    // cfg.input.visibilityToggle = Binding{Hand::Left, BoolFeature::MenuButton};
    Menu::Init(cfg);

    Category& tools = Menu::CreateCategory("Tools");
    Menu::Root().AddSubmenu("Tools", tools);

    tools.AddToggle("Log heartbeat", [] { /* runs every frame while ON */ },
                    [] { compat::Log(compat::LogLevel::Info, "heartbeat on"); },
                    [] { compat::Log(compat::LogLevel::Info, "heartbeat off"); });
    tools.AddButton("Say hi", [] { Menu::SetStatus("hi!"); });
    tools.AddSlider("Strength", 0, 4, [](int v) { compat::Log(compat::LogLevel::Info, "strength=%d", v); }, 2)
         .valueNames = {"off", "low", "mid", "high", "max"};

    // Pick any instance method that runs once per frame in YOUR game (Update / LateUpdate / FixedUpdate).
    // Find it with Il2CppDumper / dump.cs. Do NOT leave this as a placeholder:
    Menu::InstallTickHook("", "SomeGameClass", "Update");
}

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void*) {
    JNIEnv* env;
    vm->GetEnv((void**)&env, JNI_VERSION_1_6);
    BNM::Loading::TryLoadByJNI(env);
    BNM::Loading::AddOnLoadedEvent(OnLoaded);
    return JNI_VERSION_1_6;
}
